from animal import animal
# amphibi 1
class amphibi1(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernapas) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_amphibi(self):
        super().info_animal()
        print("Jenis air \t\t\t : ", self.jenis_air,
              "\nBernapas\t\t\t : ", self.bernapas,
              "\n======================================================")
        
amphibi1= amphibi1("Katak", "Serangga", "Dua alam", "bertelur", "Air tawar", "Paru-paru dan kulit")
amphibi1.info_amphibi()

# amphibi 2
class amphibi2(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernapas) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_amphibi(self):
        super().info_animal()
        print("Jenis air \t\t\t : ", self.jenis_air,
              "\nBernapas\t\t\t : ", self.bernapas,
              "\n======================================================")
        
amphibi2= amphibi2("Salamender", "Cacing", "Dua alam", "Ovovivipar", "Air tawar dan Hutan lembap", "Paru-paru, insang dan kulit")
amphibi2.info_amphibi()

# amphibi 3
class amphibi3(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernapas) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_amphibi(self):
        super().info_animal()
        print("Jenis air \t\t\t : ", self.jenis_air,
              "\nBernapas\t\t\t : ", self.bernapas,
              "\n======================================================")
        
amphibi3= amphibi3("Kadal air", "Kumbang air", "Dua alam", "Ovovivipar", "Air tawar dan Rawa", "Paru-paru dan kulit")
amphibi3.info_amphibi()
        