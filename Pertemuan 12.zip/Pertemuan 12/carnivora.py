from animal import animal

# carnivora 1
class carnivora1(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_tulangBelakang, ukuran_cakar) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_tulangBelakang = jenis_tulangBelakang
        self.ukuran_cakar= ukuran_cakar

    def info_carnivora(self):
        super().info_animal()
        print("Jenis kulit \t\t\t : ", self.jenis_tulangBelakang,
              "\nUkuran tubuh\t\t\t : ", self.ukuran_cakar,
              "\n======================================================")
        
carnivora1= carnivora1("Harimau", "Daging", "Darat", "Vivipar", "Vertebrata", "10cm")
carnivora1.info_carnivora()

# carnivora 2
class carnivora2(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_tulangBelakang, ukuran_cakar) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_tulangBelakang = jenis_tulangBelakang
        self.ukuran_cakar= ukuran_cakar

    def info_carnivora(self):
        super().info_animal()
        print("Jenis kulit \t\t\t : ", self.jenis_tulangBelakang,
              "\nUkuran tubuh\t\t\t : ", self.ukuran_cakar,
              "\n======================================================")
        
carnivora2= carnivora2("Elang", "Daging", "Udara", "Bertelur", "Vertebrata", "5,7cm-12cm")
carnivora2.info_carnivora()

# carnivora 3
class carnivora3(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_tulangBelakang, ukuran_cakar) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_tulangBelakang = jenis_tulangBelakang
        self.ukuran_cakar= ukuran_cakar

    def info_carnivora(self):
        super().info_animal()
        print("Jenis kulit \t\t\t : ", self.jenis_tulangBelakang,
              "\nUkuran tubuh\t\t\t : ", self.ukuran_cakar,
              "\n======================================================")
        
carnivora3= carnivora3("Komodo", "Daging", "Daratan", "Bertelur", "Vertebrata", "5cm")
carnivora3.info_carnivora()

