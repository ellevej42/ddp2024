from animal import animal

# mamalia 1
class mamalia1(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_kulit, ukuran_tubuh) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_kulit = jenis_kulit
        self.ukuran_tubuh = ukuran_tubuh

    def info_mamalia(self):
        super().info_animal()
        print("Jenis kulit \t\t\t : ", self.jenis_kulit,
              "\nUkuran tubuh\t\t\t : ", self.ukuran_tubuh,
              "\n======================================================")
        
mamalia1= mamalia1("Sapi", "Rumput", "Darat", "Vivipar", "Berbulu", "Besar")
mamalia1.info_mamalia()

# mamalia 2
class mamalia2(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_kulit, ukuran_tubuh) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_kulit = jenis_kulit
        self.ukuran_tubuh = ukuran_tubuh

    def info_mamalia(self):
        super().info_animal()
        print("Jenis kulit \t\t\t : ", self.jenis_kulit,
              "\nUkuran tubuh\t\t\t : ", self.ukuran_tubuh,
              "\n======================================================")
        
mamalia2= mamalia2("Gajah", "Rumput", "Darat", "Vivipar", "Sedikit berbulu", "Sangat besar")
mamalia2.info_mamalia()

# mamalia 3
class mamalia3(animal)  :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_kulit, ukuran_tubuh) :
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_kulit = jenis_kulit
        self.ukuran_tubuh = ukuran_tubuh

    def info_mamalia(self):
        super().info_animal()
        print("Jenis kulit \t\t\t : ", self.jenis_kulit,
              "\nUkuran tubuh\t\t\t : ", self.ukuran_tubuh,
              "\n======================================================")
        
mamalia3= mamalia3("Kucing", "Ikan", "Darat", "Vivipar", "Berbulu", "Kecil")
mamalia3.info_mamalia()
        